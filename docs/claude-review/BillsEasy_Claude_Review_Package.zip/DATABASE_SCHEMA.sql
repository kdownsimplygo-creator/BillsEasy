﻿-- =============================================================================
-- BILLSEASY — CURRENT SQLITE DATABASE SCHEMA (PHASE 1.1 - PHASE 1.4)
-- Generated from src/BillsEasy.Infrastructure/Persistence/DatabaseInitializer.cs
-- Target Database: SQLite 3.x (WAL mode, foreign_keys = ON)
-- =============================================================================

PRAGMA foreign_keys = ON;

-- -----------------------------------------------------------------------------
-- TABLE: Companies
-- Authoritative root aggregate for company profile and accounting metadata.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS Companies (
    Id TEXT PRIMARY KEY,
    CompanyName TEXT NOT NULL,
    PrintName TEXT NOT NULL,
    ShortName TEXT,
    Country TEXT NOT NULL DEFAULT 'India',
    StateName TEXT NOT NULL,
    StateCode TEXT NOT NULL,
    FinancialYearBeginning TEXT NOT NULL,
    BooksBeginningFrom TEXT NOT NULL,
    CurrencySymbol TEXT NOT NULL DEFAULT '₹',
    CurrencyFormalName TEXT NOT NULL DEFAULT 'INR',
    GSTIN TEXT,
    GSTRegistrationType INTEGER NOT NULL DEFAULT 1,
    IsSecurityEnabled INTEGER NOT NULL DEFAULT 0,
    CreatedAt TEXT NOT NULL,
    CreatedBy TEXT NOT NULL,
    ModifiedAt TEXT,
    ModifiedBy TEXT
);

CREATE UNIQUE INDEX IF NOT EXISTS UQ_Companies_Name 
    ON Companies(CompanyName);

-- -----------------------------------------------------------------------------
-- TABLE: FinancialYears
-- Financial year definitions belonging to a Company.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS FinancialYears (
    Id TEXT PRIMARY KEY,
    CompanyId TEXT NOT NULL,
    YearName TEXT NOT NULL,
    StartDate TEXT NOT NULL,
    EndDate TEXT NOT NULL,
    IsActive INTEGER NOT NULL DEFAULT 0,
    IsLocked INTEGER NOT NULL DEFAULT 0,
    CreatedAt TEXT NOT NULL,
    CreatedBy TEXT NOT NULL,
    ModifiedAt TEXT,
    ModifiedBy TEXT,
    FOREIGN KEY (CompanyId) REFERENCES Companies(Id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS IX_FinancialYears_CompanyId 
    ON FinancialYears(CompanyId);

-- -----------------------------------------------------------------------------
-- TABLE: AccountGroups
-- Hierarchical taxonomy for account classification (Asset, Liability, Capital, Income, Expense).
-- Sibling uniqueness: (CompanyId, ParentGroupId, Name)
-- Root uniqueness:    (CompanyId, Name) WHERE ParentGroupId IS NULL
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS AccountGroups (
    Id TEXT PRIMARY KEY,
    CompanyId TEXT NOT NULL,
    Name TEXT NOT NULL,
    ParentGroupId TEXT,
    Nature INTEGER NOT NULL,
    IsPrimary INTEGER NOT NULL DEFAULT 0,
    IsDefaultSystemGroup INTEGER NOT NULL DEFAULT 0,
    CreatedAt TEXT NOT NULL,
    CreatedBy TEXT NOT NULL,
    ModifiedAt TEXT,
    ModifiedBy TEXT,
    FOREIGN KEY (CompanyId) REFERENCES Companies(Id) ON DELETE CASCADE,
    FOREIGN KEY (ParentGroupId) REFERENCES AccountGroups(Id) ON DELETE RESTRICT
);

CREATE UNIQUE INDEX IF NOT EXISTS UQ_AccountGroups_Company_Parent_Name
    ON AccountGroups(CompanyId, ParentGroupId, Name COLLATE NOCASE)
    WHERE ParentGroupId IS NOT NULL;

CREATE UNIQUE INDEX IF NOT EXISTS UQ_AccountGroups_Company_Root_Name
    ON AccountGroups(CompanyId, Name COLLATE NOCASE)
    WHERE ParentGroupId IS NULL;

CREATE INDEX IF NOT EXISTS IX_AccountGroups_ParentGroupId 
    ON AccountGroups(ParentGroupId);

CREATE INDEX IF NOT EXISTS IX_AccountGroups_CompanyId 
    ON AccountGroups(CompanyId);

-- -----------------------------------------------------------------------------
-- TABLE: Ledgers
-- Single authoritative entity for all accounts & parties (Customers, Suppliers, Banks, Expenses, etc.)
-- Unique ledger name per Company: (CompanyId, Name COLLATE NOCASE)
-- Delete restricted when referenced by group.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS Ledgers (
    Id TEXT PRIMARY KEY,
    CompanyId TEXT NOT NULL,
    GroupId TEXT NOT NULL,
    Name TEXT NOT NULL,
    PrintName TEXT NOT NULL,
    Alias TEXT,
    OpeningBalance REAL NOT NULL DEFAULT 0.0,
    OpeningBalanceType INTEGER NOT NULL DEFAULT 1,
    BillWiseEnabled INTEGER NOT NULL DEFAULT 0,
    CreditPeriodDays INTEGER,
    CreditLimit REAL,
    AddressLine1 TEXT,
    AddressLine2 TEXT,
    City TEXT,
    StateName TEXT,
    StateCode TEXT,
    PinCode TEXT,
    Country TEXT NOT NULL DEFAULT 'India',
    GSTIN TEXT,
    GSTRegistrationType INTEGER NOT NULL DEFAULT 1,
    PAN TEXT,
    AadhaarNumber TEXT,
    ContactPerson TEXT,
    MobileNumber TEXT,
    WhatsAppNumber TEXT,
    Email TEXT,
    BankName TEXT,
    BankAccountNumber TEXT,
    BankIFSC TEXT,
    BankBranch TEXT,
    IsDefaultSystemLedger INTEGER NOT NULL DEFAULT 0,
    CreatedAt TEXT NOT NULL,
    CreatedBy TEXT NOT NULL,
    ModifiedAt TEXT,
    ModifiedBy TEXT,
    FOREIGN KEY (CompanyId) REFERENCES Companies(Id) ON DELETE CASCADE,
    FOREIGN KEY (GroupId) REFERENCES AccountGroups(Id) ON DELETE RESTRICT
);

CREATE UNIQUE INDEX IF NOT EXISTS UQ_Ledgers_Company_Name 
    ON Ledgers(CompanyId, Name COLLATE NOCASE);

CREATE INDEX IF NOT EXISTS IX_Ledgers_GroupId 
    ON Ledgers(GroupId);

CREATE INDEX IF NOT EXISTS IX_Ledgers_CompanyId 
    ON Ledgers(CompanyId);
